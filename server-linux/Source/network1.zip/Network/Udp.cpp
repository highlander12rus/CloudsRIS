#include "Udp.h"
#include <iostream>

using namespace std;

namespace Network 
{

	Udp::Udp(unsigned short portlisten1, int portReceive1)
	{
		portListen = portlisten1;
		cout << "portlisten1 construct=" << portlisten1 << endl;
		portReceive = portReceive1;
		io_serviceServer = new boost::asio::io_service();
		io_serviceClient = new boost::asio::io_service();
	}
	
	void Udp::runClient()
	{
	

	
			udp::endpoint receiver_endpoint = udp::endpoint(boost::asio::ip::address_v4::broadcast(), 13);

			udp::socket socket(*io_serviceClient);
			socket.open(udp::v4());

			socket.set_option(boost::asio::ip::udp::socket::reuse_address(true));
			boost::asio::socket_base::broadcast option(true);
			socket.set_option(option);
			
			
			std::string message = "Lolol \n";
			
			
			boost::array<char, 1> send_buf  = {{ 0 }};
    		socket.send_to(boost::asio::buffer(send_buf), receiver_endpoint);

    	boost::array<char, 128> recv_buf;
    	udp::endpoint sender_endpoint;
    	size_t len = socket.receive_from(
        boost::asio::buffer(recv_buf), sender_endpoint);
			
			
			/*socket.async_send_to\( boost::asio::buffer(recv_buf),
			receiver_endpoint, 
			boost::bind(&Udp::handle_sendBroatcast, this,
		      boost::asio::placeholders::error,
		      boost::asio::placeholders::bytes_transferred));*/
		    
		    io_serviceClient->run();  
		
	}
	
	void Udp::runServer() 
	{
		cout << "portListe =" << portListen << endl;
	    socketServer = new udp::socket(*io_serviceServer, udp::endpoint(boost::asio::ip::address_v4::broadcast(), portListen));
  
		socketServer->set_option(boost::asio::ip::udp::socket::reuse_address(true));
		boost::asio::socket_base::broadcast option(true);
		socketServer->set_option(option);
		
		runReceive();
		io_serviceServer->run();
		
		
	}
	
	void Udp::runReceive() 
	{
		boost::array<char, 1> recv_buf;
		socketServer->async_receive_from(
          boost::asio::buffer(recv_buf), remote_endpoint,
          boost::bind(&Udp::handle_receive_from, this,
            boost::asio::placeholders::error,
            boost::asio::placeholders::bytes_transferred));
	}
	
	void Udp::sendBroadcast()
	{
		//udp::endpoint remote_endpoint = udp::endpoint(boost::asio::ip::address_v4::broadcast(), 13);
		std::string message = "Lolol \n";
		socketServer->async_send_to(boost::asio::buffer(message),
		remote_endpoint, 
		boost::bind(&Udp::handle_sendBroatcast, this,
          boost::asio::placeholders::error,
          boost::asio::placeholders::bytes_transferred));
	}
	

	void Udp::handle_sendBroatcast (
 		 const boost::system::error_code& error, // Result of operation.
  		std::size_t bytes_transferred           // Number of bytes sent.
	)
	{	
			cerr << "Udp::handle_sendBroatcast" << endl;
			if (error && error != boost::asio::error::message_size)
		    	throw boost::system::system_error(error);
		    
		
			
	}
	
	void Udp::handle_receive_from (
 		 const boost::system::error_code& error, // Result of operation.
  		std::size_t bytes_transferred           // Number of bytes sent.
	)
	{
			if (error && error != boost::asio::error::message_size)
		    	throw boost::system::system_error(error);
			sendBroadcast();
			cerr << "Udp::handle_receive_from" << endl;
			runReceive();
	}
	
	
	void Udp::sendBrotcast(boost::array<char, 1024>* data)
	{
	
	}
	
	void Udp::pollServers()
	{
	
	}
	
	Udp::~Udp()
	{
		delete io_serviceServer, socketServer, io_serviceClient, socketClient;
	}		
		
	
}
